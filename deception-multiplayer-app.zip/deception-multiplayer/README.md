# DECEPTION — Multiplayer Web App (MVP)

Starter application for a dark, mysterious multiplayer deduction game using React + Tailwind CSS + Socket.IO + Node.js + TypeScript.

## Requirements
- Node.js 20+
- npm

## Run locally
Open two terminals.

### 1. Start server
```bash
cd server
npm install
npm run dev
```
Server: `http://localhost:3001`

### 2. Start client
```bash
cd client
npm install
npm run dev
```
Client: `http://localhost:5173`

Open the client in multiple browser tabs to test the lobby and game.

## Included
- Create/join rooms with room codes
- Server-assigned roles for 7 players
- Private role delivery
- Forensic clue phase
- Discussion chat
- Accusation submission (suspect + means + clue)
- Badge/elimination mechanic
- Inside Man target selection
- Murderer guesses Witness
- Host-controlled phase progression
- Responsive dark UI

## Important MVP limitations
- This is a prototype, not production-ready.
- Game requires exactly 7 connected players to start.
- Cards and solution IDs are demo data and should be expanded to match your rules.
- The current badge rule is simplified: using a badge eliminates the selected player; Evil wins when all Good-team players are eliminated.
- For production, add persistent storage, authenticated stable player identities, reconnection recovery, rate limiting, server-side timers, input validation schemas, and deployment configuration.
