import express from "express";
import { createServer } from "node:http";
import { randomBytes } from "node:crypto";
import { Server, Socket } from "socket.io";

type Role =
  | "FORENSIC_SCIENTIST" | "WITNESS" | "INVESTIGATOR"
  | "LAB_TECHNICIAN" | "MURDERER" | "ACCOMPLICE" | "INSIDE_MAN";
type Phase = "LOBBY" | "SETUP_NIGHT" | "FORENSIC_HINT" | "DISCUSSION"
  | "ACCUSATION" | "INSIDE_MAN_ACTION" | "WITNESS_GUESS" | "ENDED";
type Team = "GOOD" | "EVIL";

interface Player {
  id: string; name: string; role?: Role; connected: boolean;
  eliminated: boolean; badgeAvailable: boolean; hasAccused: boolean;
}
interface Hint { category: "LOCATION" | "CAUSE_OF_DEATH" | "SCENE"; tileId: string; }
interface Message { playerId: string; playerName: string; text: string; timestamp: number; }
interface Room {
  code: string; hostId: string; players: Player[]; phase: Phase; round: number;
  maxRounds: number; murdererId?: string; witnessId?: string; meansSolution?: string;
  clueSolution?: string; hints: Hint[]; messages: Message[]; insideManTargetId?: string;
  winner?: Team; endReason?: string;
}
interface Data { playerId?: string; roomCode?: string; }
type Ack = (result: {ok:boolean; message?:string; roomCode?:string}) => void;
type GameSocket = Socket<Record<string, (...args:any[])=>void>, Record<string, (...args:any[])=>void>, any, Data>;

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_ORIGIN ?? "http://localhost:5173", methods: ["GET", "POST"] }
});
const rooms = new Map<string, Room>();

const ROLES: Role[] = [
  "FORENSIC_SCIENTIST", "WITNESS", "INVESTIGATOR", "LAB_TECHNICIAN",
  "MURDERER", "ACCOMPLICE", "INSIDE_MAN"
];
const MEANS = [
  {id:"poison", label:"Poison"}, {id:"blunt",label:"Blunt object"},
  {id:"sharp",label:"Sharp object"}, {id:"strangulation",label:"Strangulation"}
];
const CLUES = [
  {id:"fiber",label:"Fiber"}, {id:"footprint",label:"Footprint"},
  {id:"glass",label:"Broken glass"}, {id:"note",label:"Torn note"}
];

function code(): string {
  let value: string;
  do { value = randomBytes(3).toString("hex").toUpperCase(); } while (rooms.has(value));
  return value;
}
function fail(message: string): never { throw new Error(message); }
function getRoom(roomCode: string): Room {
  const room = rooms.get(String(roomCode ?? "").toUpperCase());
  if (!room) return fail("Room tidak ditemukan.");
  return room;
}
function player(room: Room, id: string): Player {
  const p = room.players.find(x => x.id === id);
  if (!p) return fail("Anda bukan anggota room ini.");
  return p;
}
function assertPhase(room: Room, phase: Phase) {
  if (room.phase !== phase) fail(`Aksi hanya tersedia pada fase ${phase}.`);
}
function assertHost(room: Room, id: string) {
  if (room.hostId !== id) fail("Hanya host yang dapat melakukan aksi ini.");
}
function team(role?: Role): Team {
  return role === "MURDERER" || role === "ACCOMPLICE" || role === "INSIDE_MAN" ? "EVIL" : "GOOD";
}
function publicState(room: Room, viewerId: string) {
  return {
    code: room.code, hostId: room.hostId, phase: room.phase, round: room.round,
    maxRounds: room.maxRounds, winner: room.winner, endReason: room.endReason,
    players: room.players.map(p => ({
      id:p.id, name:p.name, connected:p.connected, eliminated:p.eliminated,
      badgeAvailable:p.badgeAvailable, hasAccused:p.hasAccused,
      // Never expose role until game ends.
      role: room.phase === "ENDED" ? p.role : undefined
    })),
    hints: room.hints, messages: room.messages,
    insideManTargetId: room.phase === "ENDED" ? room.insideManTargetId : undefined,
    cards: { means: MEANS, clues: CLUES },
    viewerId
  };
}
function publish(room: Room) {
  for (const p of room.players) {
    io.to(p.id).emit("room:state", publicState(room, p.id));
  }
  if (room.phase === "ENDED") {
    io.to(room.code).emit("game:ended", {winner:room.winner, reason:room.endReason});
  }
}
function end(room: Room, winner: Team, reason: string) {
  room.phase = "ENDED"; room.winner = winner; room.endReason = reason; publish(room);
}
function start(room: Room, actorId: string) {
  assertHost(room, actorId);
  if (room.phase !== "LOBBY") fail("Permainan sudah dimulai.");
  if (room.players.length !== 7) fail("Dibutuhkan tepat 7 pemain untuk memulai.");
  const shuffled = [...ROLES].sort(() => Math.random() - 0.5);
  room.players.forEach((p, i) => { p.role = shuffled[i]; p.eliminated=false; p.badgeAvailable=true; p.hasAccused=false; });
  room.murdererId = room.players.find(p=>p.role==="MURDERER")!.id;
  room.witnessId = room.players.find(p=>p.role==="WITNESS")!.id;
  room.meansSolution = MEANS[Math.floor(Math.random()*MEANS.length)].id;
  room.clueSolution = CLUES[Math.floor(Math.random()*CLUES.length)].id;
  room.round = 1; room.phase = "SETUP_NIGHT"; room.hints=[]; room.messages=[];
  for (const p of room.players) io.to(p.id).emit("game:private-role", {role:p.role});
  publish(room);
  io.to(room.code).emit("game:phase-changed", {phase:room.phase, round:room.round});
}
function nextPhase(room: Room, actorId: string) {
  assertHost(room, actorId);
  const transitions: Partial<Record<Phase,Phase>> = {
    SETUP_NIGHT:"FORENSIC_HINT", FORENSIC_HINT:"DISCUSSION",
    DISCUSSION:"ACCUSATION", ACCUSATION:"INSIDE_MAN_ACTION",
    INSIDE_MAN_ACTION:"WITNESS_GUESS"
  };
  if (room.phase === "WITNESS_GUESS") {
    if (room.round >= room.maxRounds) return end(room,"EVIL","Batas ronde tercapai.");
    room.round++; room.phase="FORENSIC_HINT";
  } else {
    const next = transitions[room.phase];
    if (!next) fail("Tidak ada transisi fase yang valid.");
    room.phase = next;
  }
  publish(room);
  io.to(room.code).emit("game:phase-changed",{phase:room.phase,round:room.round});
}
function withAck(ack: Ack, fn:()=>void) {
  try { fn(); ack({ok:true}); }
  catch (e) { ack({ok:false,message:e instanceof Error ? e.message : "Kesalahan server."}); }
}
function cleanName(value: unknown): string {
  const name = String(value ?? "").trim();
  if (!name || name.length > 24) fail("Nama harus berisi 1–24 karakter.");
  return name;
}

io.on("connection", (rawSocket) => {
  const socket = rawSocket as unknown as GameSocket;
  socket.on("room:create", (payload:any, ack:Ack) => withAck(ack,()=>{
    const name=cleanName(payload?.playerName);
    const room:Room={code:code(),hostId:socket.id,players:[{
      id:socket.id,name,connected:true,eliminated:false,badgeAvailable:true,hasAccused:false
    }],phase:"LOBBY",round:0,maxRounds:5,hints:[],messages:[]};
    rooms.set(room.code,room); socket.data.playerId=socket.id; socket.data.roomCode=room.code;
    socket.join(room.code); publish(room); ack({ok:true,roomCode:room.code});
  }));
  socket.on("room:join", (payload:any, ack:Ack) => withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); const name=cleanName(payload?.playerName);
    if(room.phase!=="LOBBY") fail("Permainan sudah dimulai.");
    if(room.players.length>=7) fail("Room sudah penuh.");
    if(room.players.some(p=>p.name.toLowerCase()===name.toLowerCase())) fail("Nama sudah digunakan.");
    room.players.push({id:socket.id,name,connected:true,eliminated:false,badgeAvailable:true,hasAccused:false});
    socket.data.playerId=socket.id; socket.data.roomCode=room.code; socket.join(room.code);
    publish(room); ack({ok:true,roomCode:room.code});
  }));
  socket.on("game:start",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); player(room,socket.id); start(room,socket.id);
  }));
  socket.on("game:next-phase",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); player(room,socket.id); nextPhase(room,socket.id);
  }));
  socket.on("forensic:hint",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"FORENSIC_HINT");
    if(player(room,socket.id).role!=="FORENSIC_SCIENTIST") fail("Hanya Forensic Scientist yang dapat memberi petunjuk.");
    const category=payload?.category;
    if(!["LOCATION","CAUSE_OF_DEATH","SCENE"].includes(category)) fail("Kategori petunjuk tidak valid.");
    const tileId=String(payload?.tileId??"").trim();
    if(!tileId || tileId.length>80) fail("Tile petunjuk tidak valid.");
    if(room.hints.some(h=>h.category===category)) fail("Kategori ini sudah memiliki petunjuk.");
    room.hints.push({category,tileId}); publish(room);
  }));
  socket.on("discussion:message",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"DISCUSSION");
    const p=player(room,socket.id); const text=String(payload?.text??"").trim();
    if(!text || text.length>500) fail("Pesan harus berisi 1–500 karakter.");
    room.messages.push({playerId:p.id,playerName:p.name,text,timestamp:Date.now()});
    if(room.messages.length>150) room.messages.shift(); publish(room);
  }));
  socket.on("accusation:submit",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"ACCUSATION");
    const p=player(room,socket.id);
    if(!["INVESTIGATOR","LAB_TECHNICIAN"].includes(p.role??"")) fail("Role ini tidak dapat menuduh.");
    if(p.eliminated || p.hasAccused) fail("Pemain tidak dapat mengajukan tuduhan lagi.");
    const suspect=String(payload?.suspectId??"");
    const means=String(payload?.meansId??"");
    const clue=String(payload?.clueId??"");
    if(!room.players.some(x=>x.id===suspect) || suspect===p.id) fail("Tersangka tidak valid.");
    if(!MEANS.some(x=>x.id===means) || !CLUES.some(x=>x.id===clue)) fail("Kartu means/clue tidak valid.");
    p.hasAccused=true;
    const correct=suspect===room.murdererId && means===room.meansSolution && clue===room.clueSolution;
    socket.emit("accusation:result",{correct});
    if(correct) end(room,"GOOD","Kombinasi tersangka, means, dan clue benar.");
    else publish(room);
  }));
  socket.on("badge:use",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"ACCUSATION");
    const p=player(room,socket.id); const targetId=String(payload?.targetId??"");
    if(p.eliminated || !p.badgeAvailable) fail("Badge tidak tersedia.");
    if(targetId===p.id) fail("Tidak dapat memilih diri sendiri.");
    const target=player(room,targetId);
    if(target.eliminated) fail("Target sudah tereliminasi.");
    p.badgeAvailable=false; target.eliminated=true;
    const goodRemaining=room.players.filter(x=>!x.eliminated && x.role && team(x.role)==="GOOD");
    if(goodRemaining.length===0) end(room,"EVIL","Semua pemain tim Good tereliminasi.");
    else publish(room);
  }));
  socket.on("inside-man:choose",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"INSIDE_MAN_ACTION");
    if(player(room,socket.id).role!=="INSIDE_MAN") fail("Hanya Inside Man yang dapat memilih target.");
    const target=player(room,String(payload?.targetId??""));
    if(target.id===socket.id || target.eliminated) fail("Target tidak valid.");
    room.insideManTargetId=target.id; publish(room);
  }));
  socket.on("witness:guess",(payload:any,ack:Ack)=>withAck(ack,()=>{
    const room=getRoom(payload?.roomCode); assertPhase(room,"WITNESS_GUESS");
    if(player(room,socket.id).role!=="MURDERER") fail("Hanya Murderer yang dapat menebak Witness.");
    const guess=String(payload?.suspectedWitnessId??"");
    if(!room.players.some(p=>p.id===guess)) fail("Pilihan tidak valid.");
    if(guess===room.witnessId) end(room,"EVIL","Murderer berhasil menebak Witness.");
    else end(room,"GOOD","Murderer gagal menebak Witness.");
  }));
  socket.on("disconnect",()=>{
    const roomCode=socket.data.roomCode; if(!roomCode) return;
    const room=rooms.get(roomCode); if(!room) return;
    const p=room.players.find(x=>x.id===socket.id);
    if(p) { p.connected=false; publish(room); }
  });
});

app.get("/health",(_req,res)=>res.json({status:"ok"}));
const port=Number(process.env.PORT??3001);
httpServer.listen(port,()=>console.log(`Deception server running at http://localhost:${port}`));
