import { useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import { Skull, Shield, Eye, Fingerprint, Radio, Users, Copy, Send, ChevronRight, CircleDot, LogOut, Clock3 } from "lucide-react";

const socket = io(import.meta.env.VITE_SERVER_URL ?? "http://localhost:3001", { autoConnect:true });
const roleNames: Record<string,string> = {
  FORENSIC_SCIENTIST:"Forensic Scientist", WITNESS:"Witness", INVESTIGATOR:"Investigator",
  LAB_TECHNICIAN:"Lab Technician", MURDERER:"Murderer", ACCOMPLICE:"Accomplice", INSIDE_MAN:"Inside Man"
};
const phaseNames: Record<string,string> = {
  LOBBY:"Lobby", SETUP_NIGHT:"Setup Night", FORENSIC_HINT:"Forensic Hint", DISCUSSION:"Discussion",
  ACCUSATION:"Accusation", INSIDE_MAN_ACTION:"Inside Man Action", WITNESS_GUESS:"Witness Guess", ENDED:"Case Report"
};
type Player = {id:string;name:string;connected:boolean;eliminated:boolean;badgeAvailable:boolean;hasAccused:boolean;role?:string};
type State = {code:string;hostId:string;phase:string;round:number;maxRounds:number;winner?:string;endReason?:string;players:Player[];hints:{category:string;tileId:string}[];messages:{playerId:string;playerName:string;text:string;timestamp:number}[];cards:{means:{id:string;label:string}[];clues:{id:string;label:string}[]};viewerId:string};
const btn = "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-40";
const primary = `${btn} bg-red-700 text-white hover:bg-red-600 shadow-lg shadow-red-950/30`;
const secondary = `${btn} border border-white/10 bg-white/[0.04] text-slate-200 hover:bg-white/[0.08]`;
function Panel({children,className=""}:{children:React.ReactNode;className?:string}){return <section className={`rounded-2xl border border-white/[0.09] bg-[#10121b]/85 p-5 shadow-2xl shadow-black/20 ${className}`}>{children}</section>}
function App(){
  const [name,setName]=useState(""); const [joinCode,setJoinCode]=useState(""); const [state,setState]=useState<State|null>(null);
  const [role,setRole]=useState<string|null>(null); const [notice,setNotice]=useState(""); const [chat,setChat]=useState("");
  const [category,setCategory]=useState("LOCATION"); const [tile,setTile]=useState("");
  const [suspect,setSuspect]=useState(""); const [means,setMeans]=useState("poison"); const [clue,setClue]=useState("fiber");
  const [target,setTarget]=useState(""); const [witnessGuess,setWitnessGuess]=useState("");
  const [tab,setTab]=useState("case");
  useEffect(()=>{
    const onState=(s:State)=>setState(s);
    const onRole=(d:{role:string})=>setRole(d.role);
    const onError=(d:{message:string})=>setNotice(d.message);
    const onAccusation=(d:{correct:boolean})=>setNotice(d.correct?"Kombinasi tuduhan benar.":"Tuduhan belum tepat.");
    socket.on("room:state",onState); socket.on("game:private-role",onRole);
    socket.on("game:error",onError); socket.on("accusation:result",onAccusation);
    return ()=>{socket.off("room:state",onState);socket.off("game:private-role",onRole);socket.off("game:error",onError);socket.off("accusation:result",onAccusation)};
  },[]);
  const me=useMemo(()=>state?.players.find(p=>p.id===socket.id),[state]);
  const isHost=!!state&&state.hostId===socket.id;
  const send=(event:string,payload:Record<string,unknown>)=>{
    socket.emit(event,payload,(r:{ok:boolean;message?:string;roomCode?:string})=>{
      if(!r?.ok) setNotice(r?.message??"Aksi gagal.");
      else if(r.roomCode) setNotice(`Room dibuat: ${r.roomCode}`);
      else setNotice("Aksi berhasil.");
    });
  };
  const create=()=>send("room:create",{playerName:name});
  const join=()=>send("room:join",{playerName:name,roomCode:joinCode});
  const leave=()=>{if(state)send("room:leave",{roomCode:state.code});setState(null);setRole(null)};
  const next=()=>state&&send("game:next-phase",{roomCode:state.code});
  const start=()=>state&&send("game:start",{roomCode:state.code});
  const copyCode=async()=>{if(state){try{await navigator.clipboard.writeText(state.code);setNotice("Kode room disalin.")}catch{setNotice(`Kode room: ${state.code}`)}}};
  const sendChat=()=>{if(state&&chat.trim()){send("discussion:message",{roomCode:state.code,text:chat});setChat("")}};
  const addHint=()=>state&&send("forensic:hint",{roomCode:state.code,category,tileId:tile});
  const accuse=()=>state&&send("accusation:submit",{roomCode:state.code,suspectId:suspect,meansId:means,clueId:clue});
  const useBadge=()=>state&&send("badge:use",{roomCode:state.code,targetId:target});
  const insideChoose=()=>state&&send("inside-man:choose",{roomCode:state.code,targetId:target});
  const guess=()=>state&&send("witness:guess",{roomCode:state.code,suspectedWitnessId:witnessGuess});
  const phase=state?.phase;
  const field="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-3 text-sm text-slate-100 outline-none focus:border-red-500/60";
  if(!state) return <main className="mx-auto flex min-h-screen max-w-6xl items-center px-5 py-12">
    <div className="grid w-full gap-10 md:grid-cols-[1.05fr_.95fr] md:items-center">
      <div><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-red-500/25 bg-red-500/10 px-3 py-1.5 text-xs uppercase tracking-[.25em] text-red-300"><Radio size={14}/> Multiplayer case files</div>
        <h1 className="text-5xl font-black tracking-tight text-white sm:text-7xl">DECEP<span className="text-red-600">TION</span></h1>
        <p className="mt-5 max-w-lg text-lg leading-8 text-slate-400">Seven players. One hidden truth. Trust no one until the evidence speaks.</p>
        <div className="mt-8 flex flex-wrap gap-3 text-xs text-slate-500"><span className="flex items-center gap-2"><Skull size={15}/> Social deduction</span><span className="flex items-center gap-2"><Fingerprint size={15}/> Secret roles</span><span className="flex items-center gap-2"><Eye size={15}/> Real-time play</span></div>
      </div>
      <Panel className="space-y-5">
        <div><p className="text-xs uppercase tracking-[.22em] text-red-400">Enter the investigation</p><h2 className="mt-2 text-2xl font-bold">Case Room</h2><p className="mt-1 text-sm text-slate-400">Masukkan nama untuk membuat atau bergabung ke room.</p></div>
        <label className="block text-sm text-slate-300">Nama pemain<input className={`${field} mt-2`} value={name} onChange={e=>setName(e.target.value)} maxLength={24} placeholder="Contoh: Raven" /></label>
        <button className={`${primary} w-full`} onClick={create} disabled={!name.trim()}><Skull size={16}/> Buat room baru</button>
        <div className="flex items-center gap-3 text-xs uppercase tracking-widest text-slate-600"><span className="h-px flex-1 bg-white/10"/>atau<span className="h-px flex-1 bg-white/10"/></div>
        <label className="block text-sm text-slate-300">Kode room<input className={`${field} mt-2 uppercase tracking-[.25em]`} value={joinCode} onChange={e=>setJoinCode(e.target.value.toUpperCase())} maxLength={6} placeholder="A1B2C3"/></label>
        <button className={`${secondary} w-full`} onClick={join} disabled={!name.trim()||joinCode.length!==6}>Gabung room <ChevronRight size={16}/></button>
        {notice&&<p className="text-sm text-red-300">{notice}</p>}
      </Panel>
    </div>
  </main>;
  return <main className="mx-auto min-h-screen max-w-7xl px-4 py-5 sm:px-7">
    <header className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
      <div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl border border-red-500/30 bg-red-500/10 text-red-400"><Skull/></div><div><h1 className="font-black tracking-[.16em] text-white">DECEPTION</h1><p className="text-xs text-slate-500">HONG KONG • CASE ROOM</p></div></div>
      <div className="flex items-center gap-2"><span className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-300">{state.code}</span><button className={secondary} onClick={copyCode}><Copy size={15}/> Salin kode</button><button className={secondary} onClick={leave}><LogOut size={15}/> Keluar</button></div>
    </header>
    {notice&&<button onClick={()=>setNotice("")} className="mb-4 w-full rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-left text-sm text-red-200">{notice} <span className="float-right">×</span></button>}
    <div className="grid gap-5 lg:grid-cols-[250px_minmax(0,1fr)]">
      <aside className="space-y-4">
        <Panel><p className="text-xs uppercase tracking-[.2em] text-slate-500">Current phase</p><h2 className="mt-2 text-xl font-bold">{phaseNames[phase??""]}</h2><p className="mt-2 flex items-center gap-2 text-sm text-slate-400"><Clock3 size={15}/> Ronde {state.round}/{state.maxRounds}</p>
          <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-red-600" style={{width:`${state.round/state.maxRounds*100}%`}}/></div>
          {role&&<div className="mt-5 rounded-xl border border-red-500/20 bg-red-500/[.07] p-3"><p className="text-[10px] uppercase tracking-[.2em] text-red-300">Your secret role</p><p className="mt-1 font-bold text-white">{roleNames[role]??role}</p></div>}
        </Panel>
        <Panel><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">Players</h3><span className="text-xs text-slate-500">{state.players.length}/7</span></div><div className="space-y-2">{state.players.map(p=><div key={p.id} className={`flex items-center gap-3 rounded-xl border p-3 ${p.id===socket.id?"border-red-500/30 bg-red-500/[.06]":"border-white/[.06] bg-black/10"}`}><div className="grid size-9 place-items-center rounded-lg bg-white/[.06] text-slate-300"><Users size={16}/></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{p.name}{p.id===socket.id?" (You)":""}</p><p className="text-[11px] text-slate-500">{p.connected?"Online":"Disconnected"}{p.eliminated?" • Eliminated":""}</p></div>{p.badgeAvailable&&!p.eliminated&&<span title="Badge tersedia" className="size-2 rounded-full bg-emerald-400"/>}</div>)}</div>
        </Panel>
      </aside>
      <section className="space-y-5">
        {phase==="LOBBY"&&<Panel><p className="text-xs uppercase tracking-[.2em] text-red-400">Gather your suspects</p><h2 className="mt-2 text-3xl font-bold">The investigation begins here.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">Undang enam pemain lain menggunakan kode room. Host dapat memulai permainan setelah tujuh pemain bergabung.</p><div className="my-6 grid gap-3 sm:grid-cols-3">{[{n:"07",t:"Players required"},{n:"07",t:"Secret roles"},{n:"05",t:"Maximum rounds"}].map(x=><div key={x.t} className="rounded-xl border border-white/[.08] bg-black/20 p-4"><p className="text-3xl font-black text-white">{x.n}</p><p className="mt-1 text-xs text-slate-500">{x.t}</p></div>)}</div>{isHost?<button className={primary} disabled={state.players.length!==7} onClick={start}>Mulai permainan <ChevronRight size={16}/></button>:<p className="text-sm text-slate-400">Menunggu host memulai permainan…</p>}</Panel>}
        {phase==="SETUP_NIGHT"&&<Panel><h2 className="text-2xl font-bold">Setup Night</h2><p className="mt-2 text-sm text-slate-400">Role rahasia sudah dibagikan. Bersiaplah untuk investigasi.</p><p className="mt-4 rounded-xl bg-black/20 p-4 text-sm text-slate-300">Jangan bagikan role rahasia melalui chat. Host dapat melanjutkan ke fase petunjuk.</p></Panel>}
        {phase==="FORENSIC_HINT"&&<Panel><p className="text-xs uppercase tracking-[.2em] text-red-400">Evidence board</p><h2 className="mt-2 text-2xl font-bold">Forensic Hint</h2><p className="mt-2 text-sm text-slate-400">Forensic Scientist mengisi satu tile untuk setiap kategori.</p>{role==="FORENSIC_SCIENTIST"&&<div className="mt-5 grid gap-3 sm:grid-cols-[1fr_1fr_auto]"><select className={field} value={category} onChange={e=>setCategory(e.target.value)}><option value="LOCATION">Location</option><option value="CAUSE_OF_DEATH">Cause of death</option><option value="SCENE">Scene</option></select><input className={field} value={tile} onChange={e=>setTile(e.target.value)} placeholder="ID / nama tile"/><button className={primary} onClick={addHint} disabled={!tile.trim()}>Kirim petunjuk</button></div>}<div className="mt-5 grid gap-3 sm:grid-cols-3">{["LOCATION","CAUSE_OF_DEATH","SCENE"].map(c=><div key={c} className="rounded-xl border border-white/[.08] bg-black/20 p-4"><p className="text-xs tracking-widest text-slate-500">{c.replaceAll("_"," ")}</p><p className="mt-2 font-semibold">{state.hints.find(h=>h.category===c)?.tileId??"Awaiting clue…"}</p></div>)}</div></Panel>}
        {phase==="DISCUSSION"&&<Panel><h2 className="text-2xl font-bold">Discussion</h2><p className="mt-2 text-sm text-slate-400">Diskusikan petunjuk dan susun teori bersama.</p><div className="mt-5 max-h-80 space-y-3 overflow-y-auto rounded-xl border border-white/[.07] bg-black/20 p-4">{state.messages.length?state.messages.map((m,i)=><div key={i}><p className="text-xs font-semibold text-red-300">{m.playerName}<span className="ml-2 font-normal text-slate-600">{new Date(m.timestamp).toLocaleTimeString()}</span></p><p className="mt-1 break-words text-sm text-slate-200">{m.text}</p></div>):<p className="text-sm text-slate-500">Belum ada pesan.</p>}</div><form className="mt-3 flex gap-2" onSubmit={e=>{e.preventDefault();sendChat()}}><input className={field} value={chat} onChange={e=>setChat(e.target.value)} maxLength={500} placeholder="Tulis teori atau pertanyaan…"/><button className={primary} disabled={!chat.trim()}><Send size={16}/></button></form></Panel>}
        {phase==="ACCUSATION"&&<Panel><h2 className="text-2xl font-bold">Accusation</h2><p className="mt-2 text-sm text-slate-400">Pilih kombinasi tersangka, means, dan clue. Aksi ini akan divalidasi server.</p><div className="mt-5 grid gap-4 sm:grid-cols-3"><label className="text-sm text-slate-400">Suspect<select className={`${field} mt-2`} value={suspect} onChange={e=>setSuspect(e.target.value)}><option value="">Pilih pemain</option>{state.players.filter(p=>p.id!==socket.id&&!p.eliminated).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label className="text-sm text-slate-400">Means<select className={`${field} mt-2`} value={means} onChange={e=>setMeans(e.target.value)}>{state.cards.means.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}</select></label><label className="text-sm text-slate-400">Clue<select className={`${field} mt-2`} value={clue} onChange={e=>setClue(e.target.value)}>{state.cards.clues.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}</select></label></div><button className={`${primary} mt-5`} onClick={accuse} disabled={!suspect||!role||!["INVESTIGATOR","LAB_TECHNICIAN"].includes(role)||!!me?.hasAccused||!!me?.eliminated}>Submit accusation</button><div className="mt-8 border-t border-white/10 pt-5"><h3 className="font-semibold">Use your badge</h3><p className="mt-1 text-sm text-slate-500">Pilih target untuk dieliminasi sesuai aturan demo.</p><div className="mt-3 flex flex-col gap-3 sm:flex-row"><select className={field} value={target} onChange={e=>setTarget(e.target.value)}><option value="">Pilih target</option>{state.players.filter(p=>p.id!==socket.id&&!p.eliminated).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select><button className={secondary} onClick={useBadge} disabled={!target||!me?.badgeAvailable||!!me?.eliminated}> <Shield size={16}/> Use badge</button></div></div></Panel>}
        {phase==="INSIDE_MAN_ACTION"&&<Panel><h2 className="text-2xl font-bold">Inside Man Action</h2><p className="mt-2 text-sm text-slate-400">Pemain dengan role Inside Man dapat memilih target.</p><div className="mt-5 flex flex-col gap-3 sm:flex-row"><select className={field} value={target} onChange={e=>setTarget(e.target.value)}><option value="">Pilih target</option>{state.players.filter(p=>p.id!==socket.id&&!p.eliminated).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select><button className={primary} onClick={insideChoose} disabled={!target||role!=="INSIDE_MAN"}>Pilih target</button></div>{state.insideManTargetId&&<p className="mt-4 text-sm text-slate-400">Target sudah dipilih.</p>}</Panel>}
        {phase==="WITNESS_GUESS"&&<Panel><h2 className="text-2xl font-bold">Witness Guess</h2><p className="mt-2 text-sm text-slate-400">Murderer dapat menebak identitas Witness. Tebakan benar membuat tim Evil menang.</p><div className="mt-5 flex flex-col gap-3 sm:flex-row"><select className={field} value={witnessGuess} onChange={e=>setWitnessGuess(e.target.value)}><option value="">Pilih pemain yang dicurigai sebagai Witness</option>{state.players.filter(p=>p.id!==socket.id).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select><button className={primary} onClick={guess} disabled={!witnessGuess||role!=="MURDERER"}>Kunci tebakan</button></div>{role!=="MURDERER"&&<p className="mt-3 text-xs text-slate-500">Hanya Murderer yang dapat mengirim tebakan.</p>}</Panel>}
        {phase==="ENDED"&&<Panel className="border-red-500/25"><div className="flex items-center gap-3 text-red-400"><Skull size={28}/><p className="text-xs uppercase tracking-[.2em]">Case closed</p></div><h2 className="mt-3 text-3xl font-black">{state.winner==="GOOD"?"GOOD TEAM WINS":"EVIL TEAM WINS"}</h2><p className="mt-2 text-slate-300">{state.endReason}</p><div className="mt-5 grid gap-2 sm:grid-cols-2">{state.players.map(p=><div key={p.id} className="flex items-center justify-between rounded-xl bg-black/20 p-3"><span>{p.name}</span><span className="text-xs text-red-300">{roleNames[p.role??""]??"Unknown"}</span></div>)}</div></Panel>}
        {phase!=="LOBBY"&&phase!=="ENDED"&&<Panel className="flex flex-wrap items-center justify-between gap-4"><div><p className="font-semibold">Host controls</p><p className="mt-1 text-sm text-slate-500">Lanjutkan setelah fase selesai.</p></div>{isHost?<button className={primary} onClick={next}>Fase berikutnya <ChevronRight size={16}/></button>:<p className="text-sm text-slate-500">Menunggu host melanjutkan fase.</p>}</Panel>}
      </section>
    </div>
    <footer className="mt-8 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-4 text-xs text-slate-600"><span>DECEPTION • Prototype build</span><span>Server-authoritative game state</span></footer>
  </main>;
}
export default App;
